﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using SQLite;

// 空白ページのアイテム テンプレートについては、http://go.microsoft.com/fwlink/?LinkId=391641 を参照してください

namespace 路線検索_win
{
    /// <summary>
    /// それ自体で使用できる空白ページまたはフレーム内に移動できる空白ページ。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            var dbPath = Path.Combine(ApplicationData.Current.LocalFolder.Path, "Shinkansen_Test.sqlite");
            this.NavigationCacheMode = NavigationCacheMode.Required;
           
        }

        /// <summary>
        /// このページがフレームに表示されるときに呼び出されます。
        /// </summary>
        /// <param name="e">このページにどのように到達したかを説明するイベント データ。
        /// このプロパティは、通常、ページを構成するために使用します。</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            // TODO: ここに表示するページを準備します。

            // TODO: アプリケーションに複数のページが含まれている場合は、次のイベントの
            // 登録によりハードウェアの戻るボタンを処理していることを確認してください:
            // Windows.Phone.UI.Input.HardwareButtons.BackPressed イベント。
            // 一部のテンプレートで指定された NavigationHelper を使用している場合は、
            // このイベントが自動的に処理されます。
        }

        private async void button1_Click(object sender, RoutedEventArgs e)
        {
            // インストール・フォルダを表すStorageFolderオブジェクト
            Windows.Storage.StorageFolder installedFolder
              = Windows.ApplicationModel.Package.Current.InstalledLocation;

            // 「text」フォルダを表すStorageFolderオブジェクトを取得する
            Windows.Storage.StorageFolder textFolder
              = await installedFolder.GetFolderAsync("text");
            var dbPath = Path.Combine(textFolder.Path, "Shinkansen_Test.sqlite");
            using (var db = new SQLite.SQLiteConnection(dbPath))
            {
                string groupzyosya;
                string groupkosya;

                groupzyosya = string.Format("select group_name from Tbl WHERE g1 = \"{0}\" or g2 = \"{0}\" or g3 = \"{0}\" or g4 = \"{0}\" or g5 = \"{0}\" or g6 = \"{0}\" or g7 = \"{0}\" or g8 = \"{0}\" or g9 = \"{0}\" or g10 = \"{0}\" or g11 = \"{0}\" or g12 = \"{0}\"", zyosyastation.Text);
                groupkosya = string.Format("select group_name from Tbl WHERE g1 = \"{0}\" or g2 = \"{0}\" or g3 = \"{0}\" or g4 = \"{0}\" or g5 = \"{0}\" or g6 = \"{0}\" or g7 = \"{0}\" or g8 = \"{0}\" or g9 = \"{0}\" or g10 = \"{0}\" or g11 = \"{0}\" or g12 = \"{0}\"", kosyastation.Text);
                
                var groupazyosya = db.Query<Tbl>(groupzyosya);
                var groupakosya = db.Query<Tbl>(groupkosya);


                string linezyosya;
                string linekosya;
                
                linezyosya = string.Format("select japanese from lineinfo WHERE tosiken LIKE \"%{0}%\" or fukusima LIKE \"%{0}%\" or yamagata LIKE \"%{0}%\" or morioka LIKE \"%{0}%\" or akita LIKE \"%{0}%\" or nagano LIKE \"%{0}%\" or niigata LIKE \"%{0}%\" or sizuoka LIKE \"%{0}%\" or kyoto LIKE \"%{0}%\" or sinosaka LIKE \"%{0}%\" or hirosima LIKE \"%{0}%\" or yamaguti LIKE \"%{0}%\" or hakata LIKE \"%{0}%\" or kagosima LIKE \"%{0}%\" or kanazawa LIKE \"%{0}%\"", zyosyastation.Text);
                linekosya = string.Format("select japanese from lineinfo WHERE tosiken LIKE \"%{0}%\" or fukusima LIKE \"%{0}%\" or yamagata LIKE \"%{0}%\" or morioka LIKE \"%{0}%\" or akita LIKE \"%{0}%\" or nagano LIKE \"%{0}%\" or niigata LIKE \"%{0}%\" or sizuoka LIKE \"%{0}%\" or kyoto LIKE \"%{0}%\" or sinosaka LIKE \"%{0}%\" or hirosima LIKE \"%{0}%\" or yamaguti LIKE \"%{0}%\" or hakata LIKE \"%{0}%\" or kagosima LIKE \"%{0}%\" or kanazawa LIKE \"%{0}%\"", kosyastation.Text);

                var linezyosyaa = db.Query<lineinfo>(linezyosya);
                var linekosyaa = db.Query<lineinfo>(linekosya);
                

                
                
                answer.Text = " ";
                int answernumber = 1;
                foreach(lineinfo lineinfoZ in linezyosyaa)
                {
                    foreach (lineinfo lineinfoK in linekosyaa)
                    {
                        if(lineinfoZ.japanese.Equals(lineinfoK.japanese))
                        {
                            string answertest = string.Format("↓　{0}", lineinfoK.japanese);
                            answer.Text += ("検索結果" + answernumber + "\r\n" + zyosyastation.Text + "\r\n" + answertest + "\r\n" + kosyastation.Text + "\r\n" + " " + "\r\n");
                            answernumber = answernumber+1;
                            break; 
                        }
                    }
                }

            }
            if (zyosyastation.Text == "")
            {
                zyosyastation.Text = "駅名を入力してください";

            }

            if (kosyastation.Text == "")
            {
                kosyastation.Text = "駅名を入力してください";
            }
        }
            

        public class Tbl
        {
            public string group_name { get; set; }
            public int x { get; set; }
            public int y { get; set; }
            public string g1 { get; set; }
            public string g2 { get; set; }
            public string g3 { get; set; }
            public string g4 { get; set; }
            public string g5 { get; set; }
            public string g6 { get; set; }
            public string g7 { get; set; }
            public string g8 { get; set; }
            public string g9 { get; set; }
            public string g10 { get; set; }
            public string g11 { get; set; }
            public string g12 { get; set; }

            // 出力形式

            public override string ToString()
            {
                return string.Format("入力された駅は{0}グループに所属しています", group_name );
            }

            
            

        }

        public class lineinfo
        {
            public string linename { get; set; }
            public string tosiken { get; set; }
            public string fukusima { get; set; }
            public string yamagata { get; set; }
            public string morioaka { get; set; }
            public string akita { get; set; }
            public string nagano { get; set; }
            public string niigata { get; set; }
            public string sizuoka { get; set; }
            public string kyoto { get; set; }
            public string sinosaka { get; set; }
            public string hirosima { get; set; }
            public string yamaguti { get; set; }
            public string hakata { get; set; }
            public string kagosima { get; set; }
            public string kanazawa { get; set; }
            public string japanese { get; set; }

            // 出力形式

            public override string ToString()
            {
                return string.Format("入力された駅には{0}が停車します", japanese);
            }
        }
        }
}
