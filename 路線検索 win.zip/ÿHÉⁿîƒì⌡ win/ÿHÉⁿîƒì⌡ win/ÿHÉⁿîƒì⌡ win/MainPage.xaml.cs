﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using SQLite;
using Windows.Storage;
using System.Diagnostics;


namespace 路線検索_win
{
    /// <summary>
    /// それ自体で使用できる空白ページまたはフレーム内に移動できる空白ページ。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        public string testkosya;
        public string testzyosya;


        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            Windows.Storage.StorageFolder installedFolder
              = Windows.ApplicationModel.Package.Current.InstalledLocation;

            // 「text」フォルダを表すStorageFolderオブジェクトを取得する
            Windows.Storage.StorageFolder textFolder
              = await installedFolder.GetFolderAsync("text");
            var dbPath = Path.Combine(textFolder.Path, "Shinkansen_Test.sqlite");
            using (var db = new SQLite.SQLiteConnection(dbPath))
            {
                string linezyosya;
                string linekosya;
                
                linezyosya = string.Format("select japanese from lineinfo WHERE tosiken LIKE \"%{0}%\" or fukusima LIKE \"%{0}%\" or yamagata LIKE \"%{0}%\" or morioka LIKE \"%{0}%\" or akita LIKE \"%{0}%\" or nagano LIKE \"%{0}%\" or niigata LIKE \"%{0}%\" or sizuoka LIKE \"%{0}%\" or kyoto LIKE \"%{0}%\" or sinosaka LIKE \"%{0}%\" or hirosima LIKE \"%{0}%\" or yamaguti LIKE \"%{0}%\" or hakata LIKE \"%{0}%\" or kagosima LIKE \"%{0}%\" or kanazawa LIKE \"%{0}%\"", zyosyastation.Text);
                linekosya = string.Format("select japanese from lineinfo WHERE tosiken LIKE \"%{0}%\" or fukusima LIKE \"%{0}%\" or yamagata LIKE \"%{0}%\" or morioka LIKE \"%{0}%\" or akita LIKE \"%{0}%\" or nagano LIKE \"%{0}%\" or niigata LIKE \"%{0}%\" or sizuoka LIKE \"%{0}%\" or kyoto LIKE \"%{0}%\" or sinosaka LIKE \"%{0}%\" or hirosima LIKE \"%{0}%\" or yamaguti LIKE \"%{0}%\" or hakata LIKE \"%{0}%\" or kagosima LIKE \"%{0}%\" or kanazawa LIKE \"%{0}%\"", kosyastation.Text);

                var linezyosyaa = db.Query<lineinfo>(linezyosya);
                var linekosyaa = db.Query<lineinfo>(linekosya);
                
                answer.Text = " ";
                int answernumber = 1;
                foreach(lineinfo lineinfoZ in linezyosyaa)
                {
                    foreach (lineinfo lineinfoK in linekosyaa)
                    {
                        if(lineinfoZ.japanese.Equals(lineinfoK.japanese))
                        {
                            string answertest = string.Format("↓　{0}", lineinfoK.japanese);
                            answer.Text += ("検索結果" + answernumber + "\r\n" + zyosyastation.Text + "\r\n" + answertest + "\r\n" + kosyastation.Text + "\r\n" + " " + "\r\n");
                            answernumber = answernumber+1;
                            break; 
                        }
                    }
                }

                if (answer.Text == null)
                {

                }

            }
            if (zyosyastation.Text == "")
            {
                zyosyastation.Text = "駅名を入力してください";

            }

            if (kosyastation.Text == "")
            {
                kosyastation.Text = "駅名を入力してください";
            }
        }
            
        public class lineinfo
        {
            public string linename { get; set; }
            public string tosiken { get; set; }
            public string fukusima { get; set; }
            public string yamagata { get; set; }
            public string morioaka { get; set; }
            public string akita { get; set; }
            public string nagano { get; set; }
            public string niigata { get; set; }
            public string sizuoka { get; set; }
            public string kyoto { get; set; }
            public string sinosaka { get; set; }
            public string hirosima { get; set; }
            public string yamaguti { get; set; }
            public string hakata { get; set; }
            public string kagosima { get; set; }
            public string kanazawa { get; set; }
            public string japanese { get; set; }
        }

        
        
        
    }
}
